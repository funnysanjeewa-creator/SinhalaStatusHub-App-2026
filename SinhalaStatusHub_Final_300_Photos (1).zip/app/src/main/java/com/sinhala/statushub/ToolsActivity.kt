package com.sinhala.statushub
import android.content.*;import android.hardware.camera2.CameraManager;import android.net.Uri;import android.os.Bundle;import android.widget.*;import androidx.appcompat.app.AppCompatActivity
class ToolsActivity:AppCompatActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,20)}
 fun x(t:String,a:()->Unit){r.addView(Button(this).apply{text=t;setOnClickListener{a()}})}
 x("YouTube"){open("https://www.youtube.com")};x("Facebook"){open("https://www.facebook.com")};x("Google"){open("https://www.google.com")};x("Camera"){startActivity(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE))};x("Torch"){torch()};setContentView(r)}
 private fun open(u:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u)))}
 private fun torch(){try{val cm=getSystemService(CAMERA_SERVICE) as CameraManager;val id=cm.cameraIdList.firstOrNull()?:return;val p=getPreferences(0);val on=!p.getBoolean("on",false);cm.setTorchMode(id,on);p.edit().putBoolean("on",on).apply();Toast.makeText(this,if(on)"Torch ON" else "Torch OFF",Toast.LENGTH_SHORT).show()}catch(e:Exception){Toast.makeText(this,"Torch unavailable",Toast.LENGTH_SHORT).show()}}
}