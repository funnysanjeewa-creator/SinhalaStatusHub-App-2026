package com.sinhala.statushub

import android.content.*
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.android.gms.ads.*
import com.sinhala.statushub.data.StatusItem
import com.sinhala.statushub.data.StatusRepository
import java.io.File

class MainActivity:AppCompatActivity(){
 private lateinit var list:LinearLayout
 private var cat="සියල්ල"; private var q=""
 override fun onCreate(b:Bundle?){super.onCreate(b);MobileAds.initialize(this)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,14,14,8)}
  root.addView(TextView(this).apply{text="සිංහල Status Hub";textSize=25f;setPadding(4,4,4,10)})
  val search=EditText(this).apply{hint="Status හොයන්න...";singleLine=true};root.addView(search)
  val hs=HorizontalScrollView(this);val cr=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
  StatusRepository.categories.forEach{c->cr.addView(Button(this).apply{text=c;setOnClickListener{cat=c;render()}})}
  hs.addView(cr);root.addView(hs)
  val tools=LinearLayout(this).apply{gravity=Gravity.CENTER}
  tools.addView(Button(this).apply{text="🛠 Tools";setOnClickListener{startActivity(Intent(this@MainActivity,ToolsActivity::class.java))}},LinearLayout.LayoutParams(0,58,1f))
  tools.addView(Button(this).apply{text="📺 TV";setOnClickListener{startActivity(Intent(this@MainActivity,TvActivity::class.java))}},LinearLayout.LayoutParams(0,58,1f))
  root.addView(tools)
  val ad=AdView(this).apply{adSize=AdSize.BANNER;adUnitId="ca-app-pub-3940256099942544/6300978111"};root.addView(ad);ad.loadAd(AdRequest.Builder().build())
  val sv=ScrollView(this);list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sv.addView(list);root.addView(sv,LinearLayout.LayoutParams(-1,0,1f))
  setContentView(root)
  search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,c:Int,d:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){q=s?.toString()?:"";render()};override fun afterTextChanged(e:android.text.Editable?){}})
  render()
 }
 private fun render(){list.removeAllViews();StatusRepository.all.filter{(cat=="සියල්ල"||it.category==cat)&&(q.isBlank()||it.text.contains(q,true))}.forEach{card(it)}}
 private fun card(item:StatusItem){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,8,0,14)}
  val im=ImageView(this).apply{layoutParams=LinearLayout.LayoutParams(-1,520);scaleType=ImageView.ScaleType.CENTER_CROP}
  assets.open(item.imageAsset).use{im.setImageBitmap(android.graphics.BitmapFactory.decodeStream(it))};box.addView(im)
  box.addView(TextView(this).apply{text=item.text;textSize=18f;setPadding(10,10,10,4)})
  val row=LinearLayout(this)
  row.addView(Button(this).apply{text="Copy";setOnClickListener{(getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("status",item.text));Toast.makeText(this@MainActivity,"Copied",Toast.LENGTH_SHORT).show()}})
  row.addView(Button(this).apply{text="Edit";setOnClickListener{startActivity(Intent(this@MainActivity,EditorActivity::class.java).putExtra("status",item.text).putExtra("asset",item.imageAsset))}})
  row.addView(Button(this).apply{text="Share";setOnClickListener{share(item)}})
  box.addView(row);list.addView(box)
 }
 private fun share(item:StatusItem){try{val f=File(cacheDir,"status_${item.id}.jpg");assets.open(item.imageAsset).use{a->f.outputStream().use{o->a.copyTo(o)}};val u=FileProvider.getUriForFile(this,"$packageName.fileprovider",f);startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="image/jpeg";putExtra(Intent.EXTRA_STREAM,u);putExtra(Intent.EXTRA_TEXT,item.text);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Share status"))}catch(e:Exception){Toast.makeText(this,"Share failed",Toast.LENGTH_SHORT).show()}}
}