package com.sinhala.statushub
import android.content.*;import android.graphics.*;import android.net.Uri;import android.os.Bundle;import android.provider.MediaStore;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import androidx.core.content.FileProvider;import java.io.File
class EditorActivity:AppCompatActivity(){
 private lateinit var frame:FrameLayout;private lateinit var image:ImageView;private lateinit var overlay:TextView;private var size=22f
 override fun onCreate(b:Bundle?){super.onCreate(b);val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,10,10,10)}
  frame=FrameLayout(this);image=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP};frame.addView(image,FrameLayout.LayoutParams(-1,0,1f))
  overlay=TextView(this).apply{text=intent.getStringExtra("status")?:"";textSize=size;setTextColor(Color.WHITE);setShadowLayer(8f,2f,2f,Color.BLACK);gravity=Gravity.CENTER;setPadding(20,20,20,20)
   setOnTouchListener(object:View.OnTouchListener{var dx=0f;var dy=0f;override fun onTouch(v:View,e:MotionEvent):Boolean{when(e.action){MotionEvent.ACTION_DOWN->{dx=v.x-e.rawX;dy=v.y-e.rawY};MotionEvent.ACTION_MOVE->{v.x=e.rawX+dx;v.y=e.rawY+dy}};return true}})}
  frame.addView(overlay,FrameLayout.LayoutParams(-2,-2,Gravity.CENTER));root.addView(frame,LinearLayout.LayoutParams(-1,0,1f))
  val r=LinearLayout(this)
  r.addView(Button(this).apply{text="Gallery";setOnClickListener{startActivityForResult(Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI),10)}})
  r.addView(Button(this).apply{text="A+";setOnClickListener{size+=2;overlay.textSize=size}})
  r.addView(Button(this).apply{text="A-";setOnClickListener{size=maxOf(12f,size-2);overlay.textSize=size}})
  r.addView(Button(this).apply{text="Save & Share";setOnClickListener{saveShare()}})
  root.addView(r);setContentView(root);intent.getStringExtra("asset")?.let{assets.open(it).use{a->image.setImageBitmap(BitmapFactory.decodeStream(a))}}
 }
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==10&&c==RESULT_OK)image.setImageURI(d?.data)}
 private fun saveShare(){val bmp=Bitmap.createBitmap(frame.width,frame.height,Bitmap.Config.ARGB_8888);frame.draw(Canvas(bmp));val f=File(cacheDir,"edited_${System.currentTimeMillis()}.jpg");f.outputStream().use{bmp.compress(Bitmap.CompressFormat.JPEG,92,it)};val u=FileProvider.getUriForFile(this,"$packageName.fileprovider",f);startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="image/jpeg";putExtra(Intent.EXTRA_STREAM,u);putExtra(Intent.EXTRA_TEXT,overlay.text.toString());addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Share edited status"))}
}