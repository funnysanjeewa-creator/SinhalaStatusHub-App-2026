# Sinhala Status Hub 2.0
- 300 Sinhala statuses: 60 each in 5 categories.
- 300 bundled original themed image assets, one per status.
- Status image + text, Copy, Share and Photo Editor.
- Gallery photo editor with draggable text and size controls.
- Search and category filtering.
- YouTube, Facebook, Google, Camera and Torch tools.
- TV section opens official/public destinations.
- AdMob TEST banner integration.
- Modular Android Studio project.

The bundled images are original generated graphic/photo-style backgrounds, not third-party stock photographs.
Replace Google AdMob TEST IDs with your own IDs before publishing.
TV destinations intentionally avoid unauthorized streams.
